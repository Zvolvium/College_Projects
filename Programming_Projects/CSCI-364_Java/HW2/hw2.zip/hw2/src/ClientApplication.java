import javax.swing.*;

public class ClientApplication {
    public static void main(String[] args) {
        JFrame frame = new JFrame("test test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

