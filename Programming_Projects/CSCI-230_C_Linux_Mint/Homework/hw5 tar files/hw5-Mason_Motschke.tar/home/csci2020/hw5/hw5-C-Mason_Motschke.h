// Mason Motschke CSCI 230 - 01
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Search(struct data *, char *, int);
