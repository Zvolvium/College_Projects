// Mason Motschke CSCI 230 - 01
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int Scan(FILE**);
