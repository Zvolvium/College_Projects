// Mason Motschke CSC 230 - 01
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Free(struct data *phoneBook, int size);
