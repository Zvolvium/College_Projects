// Mason Motschke CSCI 230
#include <stdlib.h>
#include <stdio.h>

void AddTree(Btree **, int, Llist **, Llist *);

void Pre_Order_Tree(Btree *);

void In_Order_Tree(Btree *);

void Post_Order_Tree(Btree *);

void PrintTree(Btree *);