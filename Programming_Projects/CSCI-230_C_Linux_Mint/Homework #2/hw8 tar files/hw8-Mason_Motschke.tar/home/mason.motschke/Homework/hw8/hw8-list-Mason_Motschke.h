// Mason Motschke CSCI 230
#include <stdlib.h>
#include <stdio.h>

void PrintList (Llist *);