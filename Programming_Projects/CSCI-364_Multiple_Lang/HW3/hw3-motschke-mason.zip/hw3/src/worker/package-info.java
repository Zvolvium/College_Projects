/**
 * package-info.java
 */
/**
 * Classes for the HW3 worker objects.
 * 
 * @author david
 * 
 * @see api.BrokerConfig
 * @see api.Worker
 */
package worker;