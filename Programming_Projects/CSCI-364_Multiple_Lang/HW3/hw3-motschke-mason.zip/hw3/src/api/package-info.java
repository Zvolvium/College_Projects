/**
 * package-info.java
 */
/**
 * Classes and interfaces required by the both Manager and Worker objects.
 * These are required for the third homework assignment. 
 * 
 * @author david
 * @see manager.Manager
 * @see worker.Worker
 */
package api;