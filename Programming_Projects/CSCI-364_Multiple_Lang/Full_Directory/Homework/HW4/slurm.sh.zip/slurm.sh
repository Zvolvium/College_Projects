#!/usr/bin/env bash 
#-----------------------------------
# slurm.sh
#
# Submit: 
#   sbatch slurm.sh
#
# Check status:
#   squeue | grep [userid]
#   squeue -u [userid]
#   squeue -j [jobid]
#-----------------------------------

#SBATCH --job-name=out
#SBATCH --partition=talon

# Sets the maximum time the job can run (hh:mm:ss).
#SBATCH --time=00:05:00

# Specifies nodes for the job. 
#SBATCH --ntasks=1      
#SBATCH --cpus-per-task=1    # cores 

# Sets the output files.
#SBATCH --output=./%x.%j.txt

module list
echo ""

# Sets the default team size
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
echo "Number of OpenMP Threads: $OMP_NUM_THREADS"

./s1 100000

